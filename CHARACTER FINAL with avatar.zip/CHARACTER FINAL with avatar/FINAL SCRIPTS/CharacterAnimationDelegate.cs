﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterAnimationDelegate : MonoBehaviour {

    public GameObject left_Arm_Attack_Point, right_Arm_Attack_Point, strong_Arm_Attack_Point;

    private GameObject _player;

    private void Start()
    {
        _player = GameObject.FindGameObjectWithTag("Player");
    }



    void Left_Arm_Attack_On()
    {
        left_Arm_Attack_Point.SetActive(true);
        left_Arm_Attack_Point.GetComponent<AttackUniversal>().Is_Collided = false;
        
    }

    void Left_Arm_Attack_Off()
    {
        if (left_Arm_Attack_Point.activeInHierarchy)
        {
            left_Arm_Attack_Point.SetActive(false);
            
        }
    }

    void Right_Arm_Attack_On()
    {
        right_Arm_Attack_Point.SetActive(true);
        right_Arm_Attack_Point.GetComponent<AttackUniversal>().Is_Collided = false;
    }

    void Right_Arm_Attack_Off()
    {
        if (right_Arm_Attack_Point.activeInHierarchy)
        {
            right_Arm_Attack_Point.SetActive(false);
        }
    }

    void Strong_Arm_Attack_On()
    {
        strong_Arm_Attack_Point.SetActive(true);
    }

    void Strong_Arm_Attack_Off()
    {
        if (strong_Arm_Attack_Point.activeInHierarchy)
        {
            strong_Arm_Attack_Point.SetActive(false);
            strong_Arm_Attack_Point.GetComponent<AttackUniversal>().Is_Collided = false;
        }
    }

    void Left_Arm_Tag_On()
    {
        left_Arm_Attack_Point.tag = Tags.LEFT_PUNCH_TAG;
    }

   void Left_Arm_Tag_Off()
    {
        left_Arm_Attack_Point.tag = Tags.UNTAGGED_TAG;
    }

    void Right_Arm_Tag_On()
    {
        right_Arm_Attack_Point.tag = Tags.RIGHT_PUNCH_TAG;
    }

    void Right_Arm_Tag_Off()
    {
        right_Arm_Attack_Point.tag = Tags.UNTAGGED_TAG;
    }

    void Strong_Arm_Tag_On()
    {
        strong_Arm_Attack_Point.tag = Tags.STRONG_PUNCH_TAG;
    }

    void Strong_Arm_Tag_Off()
    {
        strong_Arm_Attack_Point.tag = Tags.UNTAGGED_TAG;
    }


    void Player2_Animation_Attack_On()
    {
        _player.gameObject.GetComponent<JoystickMovementP2>().Hit = false;
        _player.gameObject.GetComponent<PlayerAttackFINALP2>().enabled = true;
    }

    void Player2_Animation_Attack_Off()
    {
        _player.gameObject.GetComponent<JoystickMovementP2>().Hit = true;
        _player.gameObject.GetComponent<PlayerAttackFINALP2>().enabled = false;
    }

    void Player1_Movement_While_Attacking_On()
    {
        _player.gameObject.GetComponent<JoystickMovement>().enabled = false;
        
    }

    void Player1_Movement_While_Attacking_Off()
    {
        _player.gameObject.GetComponent<JoystickMovement>().enabled = true;

    }
}
