﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosionFX : MonoBehaviour
{
    public GameObject boom;
    public ParticleSystem[] explosion_FX;
    public int[] amount;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //print(transform.position);
    }

    public void Explosion()
    {
        GameObject b = GameObject.Instantiate(boom, transform.position, Quaternion.identity);
        b.transform.position = new Vector3(b.transform.position.x, 1f, b.transform.position.z);
        //explosion_FX[0] = b.GetComponent<ParticleSystem>();
        explosion_FX = b.GetComponentsInChildren<ParticleSystem>();

         var emitParams = new ParticleSystem.EmitParams();
        //emitParams.position = transform.position;
        //print(emitParams.position);
        emitParams.applyShapeToPosition = true;
        int i = 0;
        foreach (ParticleSystem p in explosion_FX)
        {
            p.Emit(emitParams, amount[i]);
            i++;
        }
        
    }

}
